<!DOCTYPE html>
<html>
<head>
	<title>ZUGI</title>
<link rel="stylesheet" href="CSS/style.css">
	
</head>
<body>
<div class="header">
	<div class="container">
		<div class="logo">
			<a href="index.php" class="logo-link">
				<span class="logo-ring">
					<span class="logo-badge">Z</span>
				</span>
				<h1>ZUGI</h1>
			</a>
		</div>
		<div class="navi">
			<ul>
				<li><a href="">MEN</a></li>
				<li><a href="">WOMEN</a></li>
				<li><a href="">KIDS</a></li>
				<li><a href="">BEAUTY</a></li>
			</ul>
		</div>
		<div class="header-icons">
			<a href="">SEARCH</a>
			<a href="">CART (0)</a>
			<a href="reg.php" class="register">REGISTRATION</a>

		</div>
	</div>
</div>