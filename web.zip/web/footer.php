<div class="content4">
	<div class="container">
		<div class="footer-top">
			<div class="footer-brand">
				<h2>ZUGI</h2>
				<p>Fashion that moves with you. Elevated basics for every day.</p>
			</div>
			<div class="footer-col">
				<h4>SHOP</h4>
				<ul>
					<li><a href="">Men</a></li>
					<li><a href="">Women</a></li>
					<li><a href="">Kids</a></li>
					<li><a href="">Beauty</a></li>
				</ul>
			</div>
			<div class="footer-col">
				<h4>HELP</h4>
				<ul>
					<li><a href="">Track Order</a></li>
					<li><a href="">Returns &amp; Exchanges</a></li>
					<li><a href="">Shipping Info</a></li>
					<li><a href="">Contact Us</a></li>
				</ul>
			</div>
			<div class="footer-col">
				<h4>COMPANY</h4>
				<ul>
					<li><a href="">About Us</a></li>
					<li><a href="">Careers</a></li>
					<li><a href="">Store Locator</a></li>
				</ul>
			</div>
			<div class="footer-newsletter">
				<h4>SEND US A MESSAGE</h4>
				<p>Questions, feedback, or just say hi.</p>
				<form class="footer-form" action="save_message.php" method="POST">
					<input type="text" name="name" placeholder="Your name" required>
					<input type="email" name="email" placeholder="Your email" required>
					<textarea name="comment" placeholder="Your comment" rows="3" required></textarea>
					<button type="submit">SEND</button>
				</form>
			</div>
		</div>
		<div class="footer-divider"></div>
		<div class="footer-bottom">
			<p>&copy; 2026 ZUGI. All rights reserved.</p>
			<div class="footer-social">
				<a href="">INSTAGRAM</a>
				<a href="">FACEBOOK</a>
				<a href="">TIKTOK</a>
			</div>
			<div class="footer-legal">
				<a href="">Privacy Policy</a>
				<a href="">Terms of Service</a>
			</div>
		</div>
	</div>
</div>
</body>
</html>
